import React, { useState } from "react";


const HomeAccount = () => {
    const [name, setName]= useState({
       
    })
    const names=localStorage.getItem("name").replace(/"/g, "")
    return(
        <div>
            <h2 className="text-center">welcome {names}</h2>
        </div>
    );
};


export default HomeAccount;





import React, { useState } from "react";
import HomeAccount from "./HomeAccount";

const LoginAccount = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [flag, setFlag] = useState(false);
  const [home, setHome] = useState(true);

  const submit = (e) => {
    e.preventDefault();
    let mail = localStorage.getItem("email").replace(/"/g, "");
    let pass = localStorage.getItem("password").replace(/"/g, "");
    if (!email || !password) {
      setFlag(true);
    } else if (email !== mail || password !== pass) {
      setFlag(true);
    } else {
      setFlag(false);
      setHome(!home);
    }
  };
  return (
    <div>
      {home ? (
        <form className="col-sm-4 m-auto" onSubmit={submit}>
          <h3 className="text-center">login</h3>
          <div className="form-group">
            <input
              type="email"
              className="form-control"
              placeholder="Enter email"
              onChange={(e) => setEmail(e.target.value)}
            />
           
          </div>
          <div className="form-group">
            <input
              type="password"
              className="form-control"
              placeholder="Password"
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {flag && (
            <alert className="text-danger">
              **Please enter valid creditionals**
            </alert>
          )}
          <div className="text-center m-auto">
            <button type="submit" className="btn btn-primary ">
              Submit
            </button>
          </div>
        </form>
      ) : (
        <HomeAccount />
      )}
    </div>
  );
};

export default LoginAccount;






// this is signup form

import React, { useState } from "react";
import LoginAccount from "./LoginAccount";
import axios from "axios";
import '../Creditionals/Creditionals.css';

const CreatAccount = () => {
  const [names, setName] = useState('');
  const [numbers, setNumber] = useState('');
  const [emails, setEmail] = useState('');
  const [checks, setCheck] = useState('');
  const [passwords, setPassword] = useState("");
  const [flag, setFlag] = useState(false);
  const [login, setLogin] = useState(true);

 
  // DESTRUCTURING

  const data = {
    NAMES: names,
    PHONE: numbers,
    EMAIL: emails,
    PASSWORD: passwords,
  };
 
  //  onSUBMIT

  const submit = async (e) => {
    e.preventDefault();
    if (
      names
       ==="" ||
      numbers ==="" ||
      emails === "" ||
      passwords ==="" ||
      checks ===""
    ) {
      setFlag(true);
    } else {
      setFlag(false);
      localStorage.setItem("name", JSON.stringify(names));
      localStorage.setItem("email", JSON.stringify(emails));
      localStorage.setItem("password", JSON.stringify(passwords));
      
      console.log("saved in local storage");
      setLogin(!login);
      posting();
    }
  };

  // json API
  const posting = async () => {
    await axios
      .post("http://localhost:8000/data", data)
      .then((res) => console.log(res));
  };

  const click = () => {
    setLogin(!login);
  };
  return (
    <div>
      {login ? (
        <form className="col-sm-4 m-auto" onSubmit={submit}>
          <h3 className="text-center">SignUp</h3>
          <div className="form-group">
            <input
           
              type="text"
              className="form-control"
              placeholder="Enter Name"
              name="name"
              // value={names}
              onChange={(e) => setName(e.target.value)}
              // onChange={changing}
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              className="form-control"
              name="number"
              // value={number}
              placeholder="Enter Phone Number"
              onChange={(e) => setNumber(e.target.value)}
              // onChange={change}
            />
          </div>
          <div className="form-group">
            <input
              type="email"
              name="email"
              // value={email}
              className="form-control"
              placeholder="Enter email"
              onChange={(e) => setEmail(e.target.value)}
              // onChange={change}
            />
          </div>
          <div className="form-group">
            <input
              type="password"
              name="password"
              // value={password}
              className="form-control"
              placeholder="Password"
              onChange={(e) => setPassword(e.target.value)}
              // onChange={change}
            />
          </div>

          <div className="form-group form-check">
            <input
              type="checkbox"
              className="form-check-input"
              onChange={(e) => setCheck(e.target.value)}
              // onChange={change}
            />
            <label className="form-check-label">Check me out</label>
          </div>
          {flag && <p className="text-danger">Please fill all</p>}
          <div className="text-center d-flex flex-column">
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
            <p onClick={click}>have a account {setLogin}</p>
          </div>
        </form>
      ) : (
        <LoginAccount />
      )}
    </div>
  );
};

export default CreatAccount;