import React from 'react'
import { BrowserRouter,Route, Switch  } from 'react-router-dom';
import Header from './components/Header';
import Companies from "./components/Companies"
import Jobs from './components/Jobs';
import Interviews from './components/Interviews';
import Reviews from './components/Reviews';
import Salaries from './components/Salaries';
import Award from './components/Award';
import Salary from './components/Salary';
import Ambition from './components/Ambition';

const App = () => {
  return (
    <>
     
       <BrowserRouter>
        <Header/>

        <div className="pages">
          <Switch>
          <Route  path="/"    component={Ambition}/>
            <Route  path="/award"    component={Award}/>
            <Route path="/companies" component={Companies} />
            <Route path="/interviews"component={Interviews} />
            <Route path="/Jobs"component={Jobs} />
            <Route path="/reviews"component={Reviews} />
            <Route path="/salaries"component={Salaries} />
            <Route path="/salary"component={Salary} />
          </Switch>
        </div>
       
      </BrowserRouter>


      
 
    </>
  );
}
   
export default App



